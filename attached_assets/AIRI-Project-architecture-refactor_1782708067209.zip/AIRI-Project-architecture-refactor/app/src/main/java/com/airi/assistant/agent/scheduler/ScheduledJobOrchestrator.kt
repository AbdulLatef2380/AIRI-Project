package com.airi.assistant.agent.scheduler

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.airi.assistant.domain.event.AppEvent
import com.airi.assistant.domain.event.EventBus
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * ScheduledJobOrchestrator — durable scheduled agent task management.
 *
 * REAL EXECUTION:
 *   - Persists scheduled jobs to SharedPreferences (JSON) so they survive
 *     app restarts and process death.
 *   - Uses WorkManager for reliable background scheduling:
 *       - ONE_TIME: fires once at [delayMs] from now.
 *       - PERIODIC: fires every [intervalMinutes] (min 15 min — WorkManager floor).
 *   - Each job carries a [ScheduledJob.agentId] and [ScheduledJob.payload]
 *     that the [ScheduledAgentWorker] dispatches to the sub-agent routing layer.
 *   - Jobs can be cancelled, listed, and queried by id or agentId.
 *
 * WIRING:
 *   - [ServiceLocator.scheduledJobOrchestrator] holds the singleton.
 *   - [ProductionAgentOrchestrator] calls [schedule] when a plan step has
 *     type "SCHEDULE" (e.g., "remind me in 30 minutes to call John").
 *   - The UI can expose [listJobs] for a scheduled-task management screen.
 */
class ScheduledJobOrchestrator(private val context: Context) {

    companion object {
        private const val TAG          = "ScheduledJobOrchestrator"
        private const val PREFS_NAME   = "airi_scheduled_jobs"
        private const val KEY_JOBS     = "jobs_v1"
        private const val MIN_PERIODIC_MINUTES = 15L
    }

    private val prefs      = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val workManager = WorkManager.getInstance(context)

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Schedule a one-time agent job to fire after [delayMs] milliseconds.
     *
     * @return The [ScheduledJob] descriptor (persisted immediately).
     */
    fun scheduleOnce(
        agentId:     String,
        payload:     String,
        label:       String,
        delayMs:     Long,
        requiresNet: Boolean = false
    ): ScheduledJob {
        val job = ScheduledJob(
            id          = UUID.randomUUID().toString(),
            agentId     = agentId,
            payload     = payload,
            label       = label,
            type        = ScheduleType.ONE_TIME,
            triggerAtMs = System.currentTimeMillis() + delayMs,
            intervalMs  = null
        )
        persistJob(job)

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (requiresNet) NetworkType.CONNECTED else NetworkType.NOT_REQUIRED)
            .build()
        val data = Data.Builder()
            .putString("job_id",   job.id)
            .putString("agent_id", agentId)
            .putString("payload",  payload)
            .putString("label",    label)
            .build()
        val request = OneTimeWorkRequestBuilder<ScheduledAgentWorker>()
            .setInputData(data)
            .setConstraints(constraints)
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .addTag("airi_job_${job.id}")
            .addTag("airi_agent_$agentId")
            .build()

        workManager.enqueue(request)
        Log.i(TAG, "AIRI_PROOF SCHEDULED_JOB_QUEUED id=${job.id} agent=$agentId delayMs=$delayMs")
        EventBus.emitSync(AppEvent.GenericInfo("ScheduledJob queued: $label"))
        return job
    }

    /**
     * Schedule a repeating agent job every [intervalMinutes] minutes.
     * WorkManager enforces a 15-minute floor.
     */
    fun schedulePeriodic(
        agentId:         String,
        payload:         String,
        label:           String,
        intervalMinutes: Long,
        requiresNet:     Boolean = false
    ): ScheduledJob {
        val safeInterval = intervalMinutes.coerceAtLeast(MIN_PERIODIC_MINUTES)
        val job = ScheduledJob(
            id          = UUID.randomUUID().toString(),
            agentId     = agentId,
            payload     = payload,
            label       = label,
            type        = ScheduleType.PERIODIC,
            triggerAtMs = System.currentTimeMillis() + safeInterval * 60_000L,
            intervalMs  = safeInterval * 60_000L
        )
        persistJob(job)

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (requiresNet) NetworkType.CONNECTED else NetworkType.NOT_REQUIRED)
            .build()
        val data = Data.Builder()
            .putString("job_id",   job.id)
            .putString("agent_id", agentId)
            .putString("payload",  payload)
            .putString("label",    label)
            .build()
        val request = PeriodicWorkRequestBuilder<ScheduledAgentWorker>(
            safeInterval, TimeUnit.MINUTES
        )
            .setInputData(data)
            .setConstraints(constraints)
            .addTag("airi_job_${job.id}")
            .addTag("airi_agent_$agentId")
            .build()

        workManager.enqueue(request)
        Log.i(TAG, "AIRI_PROOF PERIODIC_JOB_QUEUED id=${job.id} agent=$agentId intervalMin=$safeInterval")
        return job
    }

    /** Cancel a scheduled job by its [jobId]. */
    fun cancel(jobId: String): Boolean {
        workManager.cancelAllWorkByTag("airi_job_$jobId")
        val removed = removePersistedJob(jobId)
        Log.i(TAG, "Job cancelled id=$jobId removed=$removed")
        return removed
    }

    /** Cancel all jobs for a specific [agentId]. */
    fun cancelByAgent(agentId: String) {
        workManager.cancelAllWorkByTag("airi_agent_$agentId")
        val all     = listJobs()
        val keep    = all.filter { it.agentId != agentId }
        persistAllJobs(keep)
        Log.i(TAG, "Cancelled all jobs for agent=$agentId count=${all.size - keep.size}")
    }

    /** All currently scheduled jobs, sorted by trigger time. */
    fun listJobs(): List<ScheduledJob> {
        val raw = prefs.getString(KEY_JOBS, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { parseJob(arr.getJSONObject(it)) }
                .sortedBy { it.triggerAtMs }
        }.getOrDefault(emptyList())
    }

    /** Query the WorkManager status for a job. */
    fun getJobStatus(jobId: String): WorkInfo.State? =
        runCatching {
            workManager.getWorkInfosByTag("airi_job_$jobId")
                .get()
                .firstOrNull()
                ?.state
        }.getOrNull()

    // ── Persistence ────────────────────────────────────────────────────────────

    private fun persistJob(job: ScheduledJob) {
        val current = listJobs().toMutableList()
        current.removeAll { it.id == job.id }
        current.add(job)
        persistAllJobs(current)
    }

    private fun removePersistedJob(jobId: String): Boolean {
        val current = listJobs().toMutableList()
        val before  = current.size
        current.removeAll { it.id == jobId }
        persistAllJobs(current)
        return current.size < before
    }

    private fun persistAllJobs(jobs: List<ScheduledJob>) {
        val arr = JSONArray()
        jobs.forEach { arr.put(jobToJson(it)) }
        prefs.edit().putString(KEY_JOBS, arr.toString()).apply()
    }

    private fun jobToJson(job: ScheduledJob): JSONObject = JSONObject().apply {
        put("id",           job.id)
        put("agent_id",     job.agentId)
        put("payload",      job.payload)
        put("label",        job.label)
        put("type",         job.type.name)
        put("trigger_at",   job.triggerAtMs)
        put("interval_ms",  job.intervalMs ?: JSONObject.NULL)
    }

    private fun parseJob(json: JSONObject) = ScheduledJob(
        id          = json.getString("id"),
        agentId     = json.getString("agent_id"),
        payload     = json.getString("payload"),
        label       = json.getString("label"),
        type        = ScheduleType.valueOf(json.getString("type")),
        triggerAtMs = json.getLong("trigger_at"),
        intervalMs  = if (json.isNull("interval_ms")) null else json.getLong("interval_ms")
    )
}

// ── Domain types ───────────────────────────────────────────────────────────────

data class ScheduledJob(
    val id:          String,
    val agentId:     String,
    val payload:     String,
    val label:       String,
    val type:        ScheduleType,
    val triggerAtMs: Long,
    val intervalMs:  Long?
)

enum class ScheduleType { ONE_TIME, PERIODIC }

